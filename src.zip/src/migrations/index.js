const createUserMigration = require('./001_create_users');
const createTaskMigration = require('./002_create_tasks');

module.exports= [
    createUserMigration,
    createTaskMigration
];