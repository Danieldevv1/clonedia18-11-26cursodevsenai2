modulo.express = {
    name : '001_create_users', 
    sql : ` 
        CREATE TABLE IF NOT EXIST users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE
        )
    `
};