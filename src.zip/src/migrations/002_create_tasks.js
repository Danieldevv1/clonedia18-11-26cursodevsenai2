modulo.express = {
    name : '002_create_tasks', 
    sql : ` 
        CREATE TABLE IF NOT EXIST tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        is_completed BOOLEAN DEFAULT FALSE
        )
    `
};