const database = require('../src/database');

database.initialize()
    .then(() =>{
        console.log('Migrations executadas com sucesso.');
        Process.exit(0);
})
.catch((error) => {
    console.error('Erro ao executar algoritimos :', error);
    process.exit(1);
});